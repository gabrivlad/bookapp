package com.bookxchange.exception;

public class BookExceptions extends RuntimeException {


    public BookExceptions(String message) {
        super(message);
    }


    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
