package com.bookxchange.pojo;

import lombok.Data;

@Data
public class Items {
    private String id;
    private VolumeInfo volumeInfo;
}
