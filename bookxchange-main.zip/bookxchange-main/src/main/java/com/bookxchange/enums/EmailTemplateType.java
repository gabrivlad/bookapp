package com.bookxchange.enums;

public enum EmailTemplateType {
    AVAILABILITY,
    RETURN_TIME_SOON,
    WARNING
}
