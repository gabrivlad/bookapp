package com.bookxchange.enums;

public enum BookStatus {
  RENTED,
  SOLD,
  AVAILABLE
}
