package com.bookxchange.enums;

public enum TransactionType {
    RENT,
    SELL,
    POINTSELL,
    TRADE
}

