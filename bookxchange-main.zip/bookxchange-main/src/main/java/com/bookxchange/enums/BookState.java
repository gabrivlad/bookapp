package com.bookxchange.enums;

public enum BookState {
    ASNEW,
    USED,
    PARTIAL_DAMAGED,
    ORIGINALBOX
}
