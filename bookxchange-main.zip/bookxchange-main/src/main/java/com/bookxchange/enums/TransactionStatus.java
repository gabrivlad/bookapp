package com.bookxchange.enums;

public enum TransactionStatus {
    PENDING,
    SUCCESS,
    FAILURE
}
