package com.bookxchange.dto;

import lombok.Data;

@Data
public class NotificationDTO {
    String marketBookUuid;
    String memberUuid;
}
